# # SyncNumberLookupSuccess

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**requestId** | **string** | ID of the request |
**result** | [**\Messente\Api\Model\SyncNumberLookupResult[]**](SyncNumberLookupResult.md) | A container for phone number info objects |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
