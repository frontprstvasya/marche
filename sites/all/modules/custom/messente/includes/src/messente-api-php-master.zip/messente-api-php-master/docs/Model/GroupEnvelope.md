# # GroupEnvelope

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**group** | [**\Messente\Api\Model\GroupResponseFields**](GroupResponseFields.md) |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
