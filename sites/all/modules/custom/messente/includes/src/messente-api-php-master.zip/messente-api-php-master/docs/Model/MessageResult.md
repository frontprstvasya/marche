# # MessageResult

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**messageId** | **string** | Unique identifier for the message |
**channel** | [**\Messente\Api\Model\Channel**](Channel.md) |  |
**sender** | **string** | Sender that was used for the message |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
