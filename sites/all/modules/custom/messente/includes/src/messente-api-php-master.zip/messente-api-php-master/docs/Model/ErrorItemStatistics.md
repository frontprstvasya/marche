# # ErrorItemStatistics

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**title** | **string** | Error title |
**details** | **string** | Error details |
**code** | [**\Messente\Api\Model\ErrorCodeStatistics**](ErrorCodeStatistics.md) |  |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
