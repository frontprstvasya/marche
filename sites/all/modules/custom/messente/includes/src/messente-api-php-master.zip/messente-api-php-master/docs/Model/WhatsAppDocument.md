# # WhatsAppDocument

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**caption** | **string** | Description for the document | [optional]
**content** | **string** | Base64-encoded image |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
