# # StatisticsReport

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**totalMessages** | **int** | Sum of all messages |
**totalPrice** | **string** | Price for all messages |
**country** | **string** | Target country of all messages |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
