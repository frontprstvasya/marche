# # FetchBlacklistSuccess

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**phoneNumbers** | **string[]** | Array of unique phone numbers | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
