# # WhatsAppText

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**previewUrl** | **bool** | Whether to display link preview if the message contains a hyperlink | [optional] [default to true]
**body** | **string** | Plaintext content for WhatsApp, can contain URLs, emojis and formatting |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
