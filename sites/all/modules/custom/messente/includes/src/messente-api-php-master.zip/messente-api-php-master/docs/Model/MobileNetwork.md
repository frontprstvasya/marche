# # MobileNetwork

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**mccmnc** | **string** | Mobile country and mobile network code | [optional]
**networkName** | **string** | Mobile network name | [optional]
**countryName** | **string** | Country name | [optional]
**countryPrefix** | **string** | Country prefix | [optional]
**countryCode** | **string** | Country code | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
