# # ContactListEnvelope

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**contacts** | [**\Messente\Api\Model\ContactResponseFields[]**](ContactResponseFields.md) | An array of contacts | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
