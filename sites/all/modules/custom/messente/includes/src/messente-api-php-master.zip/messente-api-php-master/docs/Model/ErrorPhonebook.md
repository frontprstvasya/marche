# # ErrorPhonebook

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**errors** | [**\Messente\Api\Model\ErrorItemPhonebook[]**](ErrorItemPhonebook.md) | An array of errors |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
