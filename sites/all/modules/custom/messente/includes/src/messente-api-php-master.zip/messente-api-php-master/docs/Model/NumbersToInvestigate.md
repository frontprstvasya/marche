# # NumbersToInvestigate

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**numbers** | **string[]** | Array of phone numbers |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
