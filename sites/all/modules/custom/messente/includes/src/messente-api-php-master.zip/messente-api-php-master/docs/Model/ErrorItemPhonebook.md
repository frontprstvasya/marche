# # ErrorItemPhonebook

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**title** | [**\Messente\Api\Model\ErrorTitlePhonebook**](ErrorTitlePhonebook.md) |  |
**detail** | **string** | Free form more detailed description of the error |
**code** | [**\Messente\Api\Model\ErrorCodePhonebook**](ErrorCodePhonebook.md) |  |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
