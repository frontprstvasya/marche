# # StatisticsReportSettings

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**startDate** | **\DateTime** | Start date for the report |
**endDate** | **\DateTime** | End date for the report |
**messageTypes** | **string[]** | Optional list of message types (sms, viber, whatsapp, hlr, telegram) | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
