/**
 *
 */
Drupal.behaviors.dmRestful = {
  // attach: function (context, settings) {
  //   const test = 'Test';
  //   const appkey = Drupal.settings.dmRestful.json.test;
  //
  // }
};
