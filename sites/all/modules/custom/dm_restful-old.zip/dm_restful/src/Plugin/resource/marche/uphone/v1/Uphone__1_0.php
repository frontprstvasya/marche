<?php

/**
 * @file
 * Contains \Drupal\dm_restful\Plugin\resource\marche\uphone\v1\Uphone__1_0.
 */

namespace Drupal\dm_restful\Plugin\resource\marche\uphone\v1;

use Drupal\restful\Plugin\resource\ResourceEntity;
use Drupal\restful\Plugin\resource\ResourceInterface;


/**
 * Class Uphone__1_0
 *
 * @package \Drupal\dm_restful\Plugin\resource\marche\uphone\v1
 *
 * @Resource(
 *   name = "uphone:1.0",
 *   resource = "uphone",
 *   label = "User phone",
 *   description = "Get user phone.",
 *   authenticationTypes = TRUE,
 *   authenticationOptional = TRUE,
 *   dataProvider = {
 *     "entityType": "user",
 *     "bundles": {
 *       "user"
 *     },
 *   },
 *   majorVersion = 1,
 *   minorVersion = 0
 * )
 */
class Uphone__1_0 extends ResourceEntity implements ResourceInterface {

  /**
   * {@inheritdoc}
   */
  protected function publicFields() {
    /** @var TYPE_NAME $public_fields */
    $public_fields = parent::publicFields();

    // The mail will be shown only to the own user or privileged users.
    $public_fields['phone'] = array(
      'property' => 'field_uphone',
    );

    unset($public_fields['id']);
    unset($public_fields['label']);
    unset($public_fields['self']);


    return $public_fields;
  }

}
